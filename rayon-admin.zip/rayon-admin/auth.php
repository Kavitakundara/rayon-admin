<?php
// session_start();

// if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
//     header('Location: ../index.php'); 
//     exit();
// }

// $currentRole = $_SESSION['role']; 
// $currentFile = basename($_SERVER['PHP_SELF']); 
// $currentDirectory = basename(dirname(__FILE__)); 

// $roleDirectories = [
//     'super-admin' => 'super-admin', 
//     'admin' => 'admin',             
//     'manager' => 'manager',         
// ];

// if ($roleDirectories[$currentRole] !== $currentDirectory) {
//     header('Location: /' . '');
//     exit();
// }
?>