<?php
include '../auth.php';
include '../conn.php'; // Include the database connection

// Initialize filters
$startDate = $_GET['start_date'] ?? null;
$endDate = $_GET['end_date'] ?? null;

// Fetch the total quantity of orders with date filters
$orderQuery = "SELECT SUM(quantity) AS total_quantity FROM place_order";
if ($startDate && $endDate) {
    $orderQuery .= " WHERE date BETWEEN '$startDate' AND '$endDate'";
}
$orderResult = $conn->query($orderQuery);
$totalQuantity = $orderResult->num_rows > 0 ? ($orderResult->fetch_assoc()['total_quantity'] ?? 0) : 0;

// Fetch the total sales and total sales amount with date filters
$salesQuery = "SELECT COUNT(*) AS total_sales, SUM(price) AS total_amount FROM create_sales";
if ($startDate && $endDate) {
    $salesQuery .= " WHERE date BETWEEN '$startDate' AND '$endDate'";
}
$salesResult = $conn->query($salesQuery);
$salesData = $salesResult->num_rows > 0 ? $salesResult->fetch_assoc() : ['total_sales' => 0, 'total_amount' => 0];

$totalSales = $salesData['total_sales'];
$totalSalesAmount = $salesData['total_amount'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../js/istocken.js"></script>
    <title>Super Admin Home</title>
</head>

<body>
    <div id="main-container">
        <!-- Filter Form -->
        <form method="GET" class="row g-3 my-3 mx-3">
            <div class="col-auto">
                <label for="start_date" class="form-label">Start Date:</label>
                <input type="date" id="start_date" name="start_date" class="form-control" value="<?= $startDate ?>">
            </div>
            <div class="col-auto">
                <label for="end_date" class="form-label">End Date:</label>
                <input type="date" id="end_date" name="end_date" class="form-control" value="<?= $endDate ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary mt-4">Apply Filter</button>
            </div>
        </form>

        <div id="content">
            <div class="row data-box">
                <div class="col-lg-4 col-md-3 col-sm-12">
                    <div id="totalOrdersBox" class="mg-box">
                        <i class="fas fa-cart-arrow-down"></i>
                        <h3>Total Orders Count</h3>
                        <div class="data">
                            <h4 id="totalOrders"><?= $totalQuantity ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-3 col-sm-12">
                    <div id="totalSalesBox" class="mg-box">
                        <i class="fas fa-chart-line"></i>
                        <h3>Total Sales Count</h3>
                        <div class="data">
                            <h4 id="totalSales"><?= $totalSales ?></h4>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-3 col-sm-12">
                    <div id="totalSalesAmount" class="mg-box">
                        <i class="fas fa-rupee-sign"></i>
                        <h3>Total Amount Sales</h3>
                        <div class="data">
                            <h4 id="totalSalesDigits">Rs. <?= number_format($totalSalesAmount, 2) ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../js/navcss.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>